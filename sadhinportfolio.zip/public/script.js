const menuToggle = document.getElementById('menuToggle');
const siteMenu = document.getElementById('siteMenu');
const progress = document.getElementById('scrollProgress');
const year = document.getElementById('year');

menuToggle?.addEventListener('click', () => {
  const open = siteMenu.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(open));
});

siteMenu?.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => {
  siteMenu.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
}));

const updateProgress = () => {
  const scrollable = document.documentElement.scrollHeight - window.innerHeight;
  progress.style.width = `${scrollable > 0 ? (window.scrollY / scrollable) * 100 : 0}%`;
};
window.addEventListener('scroll', updateProgress, { passive: true });
updateProgress();

if (year) year.textContent = new Date().getFullYear();

const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add('is-visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });

document.querySelectorAll('.reveal').forEach((element) => observer.observe(element));
