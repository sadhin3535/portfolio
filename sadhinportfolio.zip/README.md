# Sadhin Hossain Portfolio

A static, responsive portfolio built from the supplied CV. The LinkedIn button uses the profile URL provided by the user. Work Experience, Projects, Certifications, Courses/Training, and Achievements are intentionally omitted because no verifiable information was available in the reviewed sources.

## Run locally

From this folder:

```bash
python3 -m http.server 3000 --directory public --bind 0.0.0.0
```

Open `http://localhost:3000`.

## Publish free

### GitHub Pages

1. Create a new GitHub repository.
2. Upload the contents of the `public/` folder to the repository root.
3. Open **Settings → Pages**.
4. Select **Deploy from a branch**, choose `main`, and choose `/root`.
5. Save. GitHub will provide a free `https://username.github.io/repository-name/` URL.

### Netlify Drop

1. Go to https://app.netlify.com/drop.
2. Drag the `public/` folder onto the page.
3. Netlify will immediately provide a free temporary URL.

The CV is already bundled as `public/assets/Sadhin-Hossain-CV.pdf`, so the download button works on both the managed preview and free static hosts.
